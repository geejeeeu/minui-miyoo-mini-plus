#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdint.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <linux/input.h>
#include <png.h>

//	Reference: https://github.com/LeMaker/android-actions/tree/master/kernel/drivers/video/owl/dss
#include "de_atm7059.h"
int			fd_mem;
uint32_t		*de_map;
volatile uint32_t	*de_mem;
#define	DE		(0xB02E0000)
#define	DE_SIZE		(0x00001000)

//
//	Rumble ON(1�`100) / OFF(0)
//
void rumble(uint32_t val) {
	if (val > 100) val = 100;
	int fd = open("/sys/class/power_supply/battery/moto", O_WRONLY);
	if (fd > 0) { dprintf(fd, "%d", val); close(fd); }
}

//
//	Get Most recent file name from /tmp/next
//
char* getrecent(char *filename) {
	FILE		*fp;
	char		*fnptr;
	uint32_t	i;

	strcpy(filename, "/mnt/sdcard/Screenshots/");
	if (access(filename, F_OK)) mkdir(filename, 777);

	fnptr = filename + strlen(filename);

	if ((fp = fopen("/tmp/next", "r"))) {
		// for MiniUI
		char ename[256];
		char fname[256];
		char *strptr;
		ename[0] = 0; fname[0] = 0;
		fscanf(fp, "%*[\']%255[^\']%*[\' ]%255[^\']", ename, fname);
		fclose(fp);
		if (fname[0]) {
			if ((strptr = strrchr(fname, '.'))) *strptr = 0;
			if ((strptr = strrchr(fname, '/'))) strptr++; else strptr = fname;
			strcpy(fnptr, strptr);
		} else if (ename[0]) {
			if ((strptr = strrchr(ename, '/'))) *strptr = 0;
			if ((strptr = strrchr(ename, '.'))) *strptr = 0;
			if ((strptr = strrchr(ename, '/'))) strptr++; else strptr = ename;
			strcpy(fnptr, strptr);
		}
	}
	if (!(*fnptr)) strcat(filename, "MinUI");

	fnptr = filename + strlen(filename);
	for (i=0; i<1000; i++) {
		sprintf(fnptr, "_%03d.png", i);
		if ( access(filename, F_OK) != 0 ) break;
	} if (i > 999) return NULL;
	return filename;
}

//
//	Screenshot (png)
//
#define MAX_XRES	2560
#define MIN_XRES	64
void screenshot(void) {
	char		screenshotname[512];
	uint32_t	*buffer, *src;
	uint16_t	*src16;
	uint32_t	linebuffer[MAX_XRES], xres, yres, ofs, x, y, pix, bpp;
	FILE		*fp;
	png_structp	png_ptr;
	png_infop	info_ptr;

	if (getrecent(screenshotname) == NULL) return;

	ofs = de_mem[DE_OVL_BA0(0)/4];
	xres = (de_mem[DE_OVL_ISIZE(0)/4] & 0xFFFF) +1;
	yres = (de_mem[DE_OVL_ISIZE(0)/4] >> 16) +1;
	bpp = (!(de_mem[DE_OVL_CFG(0)/4] & 0x7))?2:4;
	if ((xres > MAX_XRES)||(xres < MIN_XRES)) return;

	if ((buffer = (uint32_t*)malloc(xres * yres * bpp)) != NULL) {
		lseek(fd_mem, ofs, SEEK_SET);
		read(fd_mem, buffer, xres * yres * bpp);

		fp = fopen(screenshotname, "wb");
		if (fp != NULL) {
			rumble(100);
			png_ptr = png_create_write_struct(PNG_LIBPNG_VER_STRING, 0, 0, 0);
			info_ptr = png_create_info_struct(png_ptr);
			png_init_io(png_ptr, fp);
			png_set_IHDR(png_ptr, info_ptr, xres, yres, 8, PNG_COLOR_TYPE_RGBA,
				PNG_INTERLACE_NONE, PNG_COMPRESSION_TYPE_DEFAULT, PNG_FILTER_TYPE_DEFAULT);
			png_write_info(png_ptr, info_ptr);
			if (bpp == 4) {
				src = buffer;
				for (y=0; y < yres; y++) {
					for (x=0; x < xres; x++){
						pix = *src++;
						linebuffer[x] = 0xFF000000 | (pix & 0x0000FF00) | (pix & 0x00FF0000)>>16 | (pix & 0x000000FF)<<16;
					}
					png_write_row(png_ptr, (png_bytep)linebuffer);
				}
			} else {
				src16 = (uint16_t*)buffer;
				for (y=0; y < yres; y++) {
					for (x=0; x < xres; x++){
						pix = *src16++;
						linebuffer[x] = 0xFF000000 |
							(pix & 0xF100)>>8 | (pix & 0xE000)>>13 |
							(pix & 0x07E0)<<5 | (pix & 0x0600)>>1 |
							(pix & 0x001F)<<19 | (pix & 0x001C)<<14 ;
					}
					png_write_row(png_ptr, (png_bytep)linebuffer);
				}
			}
			png_write_end(png_ptr, info_ptr);
			png_destroy_write_struct(&png_ptr, &info_ptr);
			fclose(fp);
			sync();
			rumble(0);
		}
		free(buffer);
	}
}

//
//	Screenshot Sample Main
//
#define	BUTTON_L2	KEY_HOME
#define	BUTTON_R2	KEY_UP
int main() {
	int			input_fd;
	struct input_event	ev;
	uint32_t		val;
	uint32_t		l2_pressed = 0;
	uint32_t		r2_pressed = 0;

	// Prepare for Poll button input
	input_fd = open("/dev/input/event1", O_RDONLY);

	// Prepare for read DE
	fd_mem = open("/dev/mem", O_RDONLY);
	de_map = mmap(0, DE_SIZE, PROT_READ, MAP_SHARED, fd_mem, DE);
	de_mem = de_map;

	while( read(input_fd, &ev, sizeof(ev)) == sizeof(ev) ) {
		val = ev.value;
		if (( ev.type != EV_KEY ) || ( val > 1 )) continue;
		if (( ev.code == BUTTON_L2 )||( ev.code == BUTTON_R2 )) {
			if ( ev.code == BUTTON_L2 ) {
				l2_pressed = val;
			} else if ( ev.code == BUTTON_R2 ) {
				r2_pressed = val;
			}
			if (l2_pressed & r2_pressed) {
				screenshot();
				l2_pressed = r2_pressed = 0;
			}
		}
	}

	// Quit
	munmap(de_map, DE_SIZE);
	close(fd_mem);
	close(input_fd);

	return 0;
}
