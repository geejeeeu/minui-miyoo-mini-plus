#include <stdio.h>
#include <unistd.h>
#include <stdint.h>
#include <SDL/SDL.h>
#include <SDL/SDL_ttf.h>

//
//	PrintStr Main
//
int main(int argc, char* argv[]) {
	TTF_Font	*font;
	SDL_Color	color={255,155,58,0};
	SDL_Surface	*video, *screen_tmp, *image;
	SDL_Rect	rect;
	int16_t		height, center_y;
	uint32_t	size;

	if (argc == 2) {
		SDL_Init(SDL_INIT_VIDEO);
		video = SDL_SetVideoMode(640, 480, 16, SDL_HWSURFACE);

		SDL_FillRect(video, NULL, 0);

		size = 640 / strlen(argv[1]);
		if (size < 24) size = 24;
		if (size > 128) size = 128;

		TTF_Init();
		font = TTF_OpenFont("/mnt/sdcard/.system/res/BPreplayBold-unhinted.otf", size);
		image = TTF_RenderUTF8_Blended(font, argv[1], color);
		TTF_CloseFont(font);
		TTF_Quit();

		height = image->w * 3 / 4;
		center_y = (height-image->h)/2;
		rect.x = 0;
		rect.y = center_y;
		rect.w = (uint16_t)image->w;
		rect.h = (uint16_t)(center_y + image->h);

		screen_tmp = SDL_CreateRGBSurface(0, image->w, height, 16, 0xF800, 0x7E0, 0x1F, 0);
		SDL_BlitSurface(image, NULL, screen_tmp, &rect);
		SDL_FreeSurface(image);

		SDL_SoftStretch(screen_tmp, NULL, video, NULL);
		SDL_FreeSurface(screen_tmp);

		// Quit
		setenv("SDL_FBCON_DONT_CLEAR", "1", 0);
		SDL_Quit();
	}
	return 0;
}
